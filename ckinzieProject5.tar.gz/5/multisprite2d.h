#ifndef MULTISPRITE2D__H
#define MULTISPRITE2D__H
#include <string>
#include <vector>
#include <cmath>
#include "drawable.h"

class ExplodingSprite;

class MultiSprite2d : public Drawable {
public:
  MultiSprite2d(const std::string&, const std::string&);
  MultiSprite2d(const MultiSprite2d&);
  ~MultiSprite2d();

  virtual void draw() const;
  virtual void update(Uint32 ticks);

  virtual const Image* getImage() const { 
    return images[currentFrame]; 
  }
  int getScaledWidth()  const { 
    return getScale()*images[currentFrame]->getWidth(); 
  } 
  int getScaledHeight()  const { 
    return getScale()*images[currentFrame]->getHeight(); 
  } 
  virtual const SDL_Surface* getSurface() const { 
    return images[currentFrame]->getSurface();
  }
  void flipSprite() {
    facingRight = !facingRight; }

  virtual void explode();

protected:
  std::vector<Image *> images;
  std::vector<Image *> imagesR;
  ExplodingSprite* explosion;

  unsigned currentFrame;
  unsigned numberOfFrames;
  unsigned frameInterval;
  float timeSinceLastFrame;
  int worldWidth;
  int worldHeight;
  bool facingRight;

  void advanceFrame(Uint32 ticks);
  MultiSprite2d& operator=(const MultiSprite2d&);
};
#endif
